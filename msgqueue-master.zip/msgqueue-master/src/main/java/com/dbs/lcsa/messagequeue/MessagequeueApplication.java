package com.dbs.lcsa.messagequeue;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MessagequeueApplication {

    public static void main(String[] args) {
        SpringApplication.run(MessagequeueApplication.class, args);
    }

}
